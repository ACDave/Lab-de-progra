# -*- coding: cp1252 -*-
import os
from tkinter import *
from tkinter import messagebox

tk= Tk()
tk.geometry("100x100")

def script():
    while True:
        print("�Qu� deseas hacer?\n Informacion de IP [1] \nContenido del DNS [2] \nSalir[3]")
        desicion=str(input())
        if desicion == "1":
            tk.quit()
            print("�C�mo desea la informaci�n?\n Normal[1]\n Detallada[2]")
            desicion2= input()
            if desicion2 == "1":
                print("Mostrando informaci�n...\n")
                print(os.system("ipconfig"))
            else:
                print("Mostrando informaci�n...\n")
                print(os.system("ipconfig /all"))
            
        elif desicion== "2":
            tk.quit()
            print("�Qu� desea con la informaci�n?\n Mostrar informacion [1]\n Borrar [2]")
            desicion3= input()

            if desicion3 == "1":
                print("Mostrando informaci�n...\n")
                print(os.system("ipconfig /displaydns"))
            else:
                print("Borrando datos...\n")
                os.system("ipconfig /flushdns")
            
        elif desicion == "3":
            tk.destroy()
            break
    

but= Button(tk, text= "run info script", command=script)
but.place(x= 20, y=50)
tk.mainloop()

        
